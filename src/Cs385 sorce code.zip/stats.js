export const climateStats = 
        {
            electric: 105,
            gas: 105,
            oil: 113,
            car: 0.79,
            longflight: 1100,
            shortflight: 4400,
            paper: 184,
            metal: 166

        };

